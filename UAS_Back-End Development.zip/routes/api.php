<?php
$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

$uri = str_replace('/BE_DEV/uas', '', $uri);
$method = $_SERVER['REQUEST_METHOD'];

require_once __DIR__ . '/../controllers/AuthController.php';
require_once __DIR__ . '/../controllers/StudentController.php';
require_once __DIR__ . '/../middleware/AuthMiddleware.php';

if (!isset($pdo)) {
    echo json_encode(['debug' => 'PDO not set']);
    exit;
}

if ($uri == '/api/auth/login' && $method == 'POST') {
    login($pdo);
} elseif ($uri == '/api/auth/me' && $method == 'GET') {
    authMiddleware($pdo, 'me');
} elseif ($uri == '/api/students' && $method == 'GET') {
    authMiddleware($pdo, 'getAllStudents');
} elseif (preg_match('#^/api/students/(\d+)$#', $uri, $m) && $method == 'GET') {
    authMiddleware($pdo, 'getStudent', $m[1]);
} elseif ($uri == '/api/students' && $method == 'POST') {
    authMiddleware($pdo, 'createStudent');
} elseif (preg_match('#^/api/students/(\d+)$#', $uri, $m) && $method == 'PUT') {
    authMiddleware($pdo, 'updateStudent', $m[1]);
} elseif (preg_match('#^/api/students/(\d+)$#', $uri, $m) && $method == 'DELETE') {
    authMiddleware($pdo, 'deleteStudent', $m[1]);
} else {
    http_response_code(404);
    echo json_encode(['message' => 'Endpoint not found']);
}

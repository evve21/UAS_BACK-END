CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(255) NOT NULL
);

CREATE TABLE students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    nim VARCHAR(20),
    major VARCHAR(100)
);

-- Superadmin (username: admin, password: admin123)
INSERT INTO users (username, password) VALUES (
    'admin',
    '$2y$10$.e9P0HQlccTfUsLrjETx3eSgkp8wvlPiZu7kOynQlYNT0Ko7FqOvy'
);
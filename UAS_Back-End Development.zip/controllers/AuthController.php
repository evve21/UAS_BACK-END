<?php
use Firebase\JWT\JWT;

function login($pdo) {
    $data = json_decode(file_get_contents("php://input"), true);
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$data['username']]);
    $user = $stmt->fetch();

    if (!$user) {
        echo json_encode(['error' => 'User not found']);
        return;
    }

    if (!password_verify($data['password'], $user['password'])) {
        echo json_encode(['error' => 'Wrong password']);
        return;
    }

    if ($user && password_verify($data['password'], $user['password'])) {
        $payload = ['id' => $user['id'], 'username' => $user['username'], 'exp' => time() + 3600];
        $token = JWT::encode($payload, 'secretkey', 'HS256');
        echo json_encode(['token' => $token]);
    } else {
        http_response_code(401);
        echo json_encode(['message' => 'Invalid credentials']);
    }
}

function me($pdo, $userId) {
    $stmt = $pdo->prepare("SELECT id, username FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    echo json_encode($stmt->fetch());
}
<?php
function getAllStudents($pdo) {
    echo json_encode($pdo->query("SELECT * FROM students")->fetchAll());
}

function getStudent($pdo, $userId, $id) {
    $stmt = $pdo->prepare("SELECT * FROM students WHERE id = ?");
    $stmt->execute([$id]);
    $student = $stmt->fetch();

    if ($student) {
        echo json_encode($student);
    } else {
        http_response_code(404);
        echo json_encode(['message' => 'Student not found']);
    }
}

function createStudent($pdo, $userId) {
    $data = json_decode(file_get_contents("php://input"), true);
    $stmt = $pdo->prepare("INSERT INTO students (name, nim, major) VALUES (?, ?, ?)");
    $stmt->execute([$data['name'], $data['nim'], $data['major']]);
    echo json_encode(['message' => 'Student created']);
}

function updateStudent($pdo, $userId, $id) {
    $data = json_decode(file_get_contents("php://input"), true);
    $stmt = $pdo->prepare("UPDATE students SET name = ?, nim = ?, major = ? WHERE id = ?");
    $stmt->execute([$data['name'], $data['nim'], $data['major'], $id]);
    echo json_encode(['message' => 'Student updated']);
}

function deleteStudent($pdo, $userId, $id) {
    $stmt = $pdo->prepare("DELETE FROM students WHERE id = ?");
    $stmt->execute([$id]);
    echo json_encode(['message' => 'Student deleted']);
}
<?php
use Firebase\JWT\JWT;
use Firebase\JWT\Key;

function authMiddleware($pdo, $callbackName, $param = null) {
    $headers = getallheaders();
    if (!isset($headers['Authorization'])) {
        http_response_code(401);
        echo json_encode(['message' => 'Unauthorized']);
        exit;
    }

    $token = str_replace('Bearer ', '', $headers['Authorization']);
    try {
        $decoded = JWT::decode($token, new Key('secretkey', 'HS256'));
        if (function_exists($callbackName)) {
            $param ? $callbackName($pdo, $decoded->id, $param) : $callbackName($pdo, $decoded->id);
        }
    } catch (Exception $e) {
        http_response_code(401);
        echo json_encode(['message' => 'Invalid token']);
    }
}